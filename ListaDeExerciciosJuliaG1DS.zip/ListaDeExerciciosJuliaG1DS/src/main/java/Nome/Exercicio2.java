/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nome;

import java.util.Scanner;

/**
 *
 * @author Julia
 */
public class Exercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { 
        
        String seilá;
        
        Scanner nome = new Scanner(System.in);
        
        System.out.println(" Digite seu nome: ");
        seilá = nome.next() ;
        
        double ab;
        
        Scanner abc = new Scanner(System.in);
        
        System.out.println(" Digite a nota da sua primeira prova: ");
        ab = abc.nextDouble() ;
        
        double abcd;
        
        Scanner abcde = new Scanner(System.in);
        
        System.out.println(" Digite a nota da sua segunda prova: ");
        abcd = abcde.nextDouble() ;
        
        double abcdef;
        
        Scanner abcdefg = new Scanner(System.in);
        
        System.out.println(" Digite a nota da sua terceira prova: ");
        abcdef = abcdefg.nextDouble() ;
        
        double abcdefgh;
        
        Scanner abcdefghi = new Scanner(System.in);
        
        System.out.println(" Digite a nota da sua última prova: ");
        abcdefgh = abcdefghi.nextDouble() ;
        
        double resultado;
        double a = ab ;
        double b = abcd ;
        double c = abcdef;
        double d = abcdefgh;
        
        resultado = a/4 + b/4 + c/4 + d/4;
        
        System.out.println("Seu nome é " +seilá+ " e sua média é: " +resultado);
        
       
    }
    
}
