
package Nome;

import java.util.Scanner;

/**
 *
 * @author Julia
 */
public class Exercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        double a;
        
        Scanner b = new Scanner(System.in);
        
        System.out.println(" Digite a quantidade quilometros que você quer converter: ");
        a = b.nextDouble() ;
        
        double resultado;
        resultado = a/1.60934;
        
        System.out.println("Este número, em milhas, é: " +resultado );
    }
    
}
