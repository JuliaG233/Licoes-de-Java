/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nome;

import java.util.Scanner;

/**
 *
 * @author Julia
 */
public class Exercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double c;
        
        Scanner b = new Scanner(System.in);
        
        System.out.println(" Digite um número para saber sua tabuada: ");
        c = b.nextDouble() ;
        
        double resultado1;
        double resultado2;
        double resultado3;
        double resultado4;
        double resultado5;
        double resultado6;
        double resultado7;
        double resultado8;
        double resultado9;
        double resultado10;
        double a = c;
        
        resultado1 = c*1;
        resultado2 = c*2;
        resultado3 = c*3;
        resultado4 = c*4;
        resultado5 = c*5;
        resultado6 = c*6;
        resultado7 = c*7;
        resultado8 = c*8;
        resultado9 = c*9;
        resultado10 = c*10;        
        
        System.out.println("A tabuada desse número é" +resultado1+ " "+resultado2+ " "+resultado3+ " "+resultado4+ " "+resultado5+ " "+resultado6+ " "+resultado7+ " "+resultado8+ " "+resultado9+ " "+resultado10+ " ");
    }
    
}
