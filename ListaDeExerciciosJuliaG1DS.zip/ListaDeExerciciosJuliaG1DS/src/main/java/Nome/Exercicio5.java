/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nome;

import java.util.Scanner;

/**
 *
 * @author Julia
 */
public class Exercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Eu coloquei 31 dias, porque tem mais meses que tem 31 dias do que 30
        int a;
        
        Scanner b = new Scanner(System.in);
        
        System.out.println("Escreva a quantidade de meses que deseja converter para dias: ");
        a = b.nextInt() ;
        
        int resultado;
        resultado = a*31;
        
        System.out.println("O resultado da conversão é: " +resultado );
    }
    
}
